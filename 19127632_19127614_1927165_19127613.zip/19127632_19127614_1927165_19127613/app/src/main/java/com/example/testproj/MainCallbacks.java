package com.example.testproj;

public interface MainCallbacks {
    public void onMsgFromFragToMain(String sender, FragmentBlue.infor strValue);
}
